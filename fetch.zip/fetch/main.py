import base64
import requests
import logging
import os
from datetime import datetime, timezone, timedelta
from jira import JIRA
import msal
from sqlalchemy.orm import Session
from core.config import settings
from models.models import NewTicket
from core.database import SessionLocal, init_db
from urllib.parse import quote
from bs4 import BeautifulSoup
from extractors.extractor import DocumentExtractor
from mailgun.mailgun_client import MailgunClient
import asyncio
import json
import warnings
import magic

# Set up logging
os.makedirs(os.path.dirname(settings.LOG_FILE), exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(settings.LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Initialize database
init_db()

# Initialize DocumentExtractor and MailgunClient
extractor = DocumentExtractor()
mailgun_client = MailgunClient()

def extract_value(field):
    """Extract the 'display_value' from a ServiceNow field if it's a dictionary, else return the field as-is."""
    if isinstance(field, dict) and 'display_value' in field:
        return field['display_value']
    return field

def fetch_user_email(user_link):
    """Fetch the user's email from the sys_user table using the provided link."""
    try:
        response = requests.get(
            user_link,
            auth=(settings.SNOW_AUTH_USERNAME, settings.SNOW_AUTH_PASSWORD),
            headers={"Accept": "application/json"}
        )
        if response.status_code != 200:
            logger.error(f"Failed to fetch user email from ServiceNow: {response.status_code} - {response.text}")
            return None

        user_data = response.json().get('result', {})
        email = user_data.get('email', None)
        return email
    except Exception as e:
        logger.error(f"Error fetching user email from ServiceNow: {str(e)}", exc_info=True)
        return None

async def fetch_servicenow_attachments(sys_id):
    """Fetch and extract content from ServiceNow ticket attachments."""
    try:
        session = requests.Session()
        session.auth = (settings.SNOW_AUTH_USERNAME, settings.SNOW_AUTH_PASSWORD)
        session.headers.update({"Accept": "application/json"})

        base_url = settings.SNOW_API_URL.rsplit('/table/incident', 1)[0]
        attachment_query_url = f"{base_url}/table/sys_attachment?sysparm_query=table_name=incident^table_sys_id={sys_id}"
        response = session.get(attachment_query_url)
        if response.status_code != 200:
            logger.error(f"Failed to fetch ServiceNow attachment metadata for sys_id {sys_id}: {response.status_code} - {response.text}")
            return {}

        attachments = response.json().get('result', [])
        attachment_data = {}
        instance_base = settings.SNOW_API_URL.rsplit('/api/now', 1)[0]
        
        for attachment in attachments:
            file_name = attachment.get('file_name', '')
            content_type = attachment.get('content_type', '')
            attachment_sys_id = attachment.get('sys_id', '')
            if not attachment_sys_id:
                logger.warning(f"No sys_id for attachment {file_name} in sys_id {sys_id}")
                continue
            try:
                download_url = f"{base_url}/attachment/{attachment_sys_id}/file"
                download_response = session.get(
                    download_url,
                    headers={"Accept": content_type}
                )
                download_response.raise_for_status()

                file_content = download_response.content
                mime_type = magic.from_buffer(file_content, mime=True)
                if mime_type != content_type:
                    logger.warning(f"Mismatch in content type for {file_name}: expected {content_type}, got {mime_type}")
                
                debug_dir = "debug_attachments"
                os.makedirs(debug_dir, exist_ok=True)
                debug_path = os.path.join(debug_dir, f"{attachment_sys_id}_{file_name}")
                with open(debug_path, "wb") as f:
                    f.write(file_content)
                logger.info(f"Saved raw attachment to {debug_path}")

                content = await extractor.extract_content(
                    file_content=file_content,
                    filename=file_name,
                    content_type=content_type
                )
                if content:
                    attachment_data[file_name] = content
                else:
                    logger.warning(f"No content extracted from {file_name}")
            except Exception as e:
                logger.error(f"Error processing ServiceNow attachment {file_name} for sys_id {sys_id}: {str(e)}")
                logger.debug(f"First 100 bytes of {file_name}: {file_content[:100]}")
        return attachment_data
    except Exception as e:
        logger.error(f"Error fetching ServiceNow attachments for sys_id {sys_id}: {str(e)}")
        return {}
    finally:
        session.close()

async def fetch_servicenow_tickets():
    """Fetch new or updated tickets from ServiceNow within the last 24 hours."""
    try:
        date_filter = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')
        query = f"sys_created_on>={date_filter}^ORDERBYsys_created_on"
        url = f"{settings.SNOW_API_URL}?sysparm_query={quote(query)}&sysparm_display_value=true&sysparm_limit=100"
        response = requests.get(
            url,
            auth=(settings.SNOW_AUTH_USERNAME, settings.SNOW_AUTH_PASSWORD),
            headers={"Accept": "application/json"}
        )
        if response.status_code != 200:
            logger.error(f"Failed to fetch ServiceNow tickets: {response.status_code} - {response.text}")
            return []

        tickets_data = response.json().get('result', [])
        logger.info(f"Fetched {len(tickets_data)} tickets from ServiceNow")
        normalized_tickets = []

        for ticket_data in tickets_data:
            ticket_id = extract_value(ticket_data.get('number', 'unknown'))
            sys_id = extract_value(ticket_data.get('sys_id', 'unknown'))
            caller_id = ticket_data.get('caller_id', {})
            email = None
            if caller_id and 'link' in caller_id:
                user_link = caller_id.get('link')
                email = fetch_user_email(user_link)
            if not email:
                created_by = extract_value(ticket_data.get('sys_created_by', 'unknown'))
                email = f"{created_by}@servicenow.com" if created_by != 'unknown' else 'unknown@company.com'
            short_description = extract_value(ticket_data.get('short_description', 'No subject'))
            description = extract_value(ticket_data.get('description', 'No description provided'))
            comments = extract_value(ticket_data.get('comments', ''))
            comment_content = ''
            if comments:
                comment_lines = comments.split('\n')
                for line in comment_lines:
                    if not line.startswith('20') and '(Additional comments)' not in line:
                        comment_content += line.strip() + ' '
                comment_content = comment_content.strip()
            description_body = comment_content if comment_content else description
            description = f"Subject: {short_description}\n\n{description_body}"
            severity = extract_value(ticket_data.get('severity', None))
            category = extract_value(ticket_data.get('category', None))
            state = extract_value(ticket_data.get('state', 'new'))
            status = 'resolved' if state.lower() in ['closed', 'resolved', 'cancelled'] else 'new'
            resolution = extract_value(ticket_data.get('close_notes', None))
            created_on = extract_value(ticket_data.get('sys_created_on', None))
            updated_on = extract_value(ticket_data.get('sys_updated_on', None))

            created_at = datetime.strptime(created_on, '%Y-%m-%d %H:%M:%S') if created_on else datetime.now(timezone.utc)
            updated_at = datetime.strptime(updated_on, '%Y-%m-%d %H:%M:%S') if updated_on else created_at

            additional_info = await fetch_servicenow_attachments(sys_id)

            normalized_tickets.append({
                "ticket_id": ticket_id,
                "sys_id": sys_id,
                "email": email,
                "description": description,
                "status": status,
                "priority": severity,
                "team": category,
                "resolution": resolution,
                "created_at": created_at,
                "updated_at": updated_at,
                "source": "servicenow",
                "additional_info": additional_info
            })

        return normalized_tickets
    except Exception as e:
        logger.error(f"Error fetching ServiceNow tickets: {str(e)}", exc_info=True)
        return []

async def fetch_jira_attachments(jira, issue):
    """Fetch and extract content from Jira issue attachments."""
    try:
        attachment_data = {}
        for attachment in issue.fields.attachment:
            file_name = attachment.filename
            content_type = attachment.mimeType
            try:
                content = await asyncio.to_thread(attachment.get)
                extracted_content = await extractor.extract_content(
                    file_content=content,
                    filename=file_name,
                    content_type=content_type
                )
                if extracted_content:
                    attachment_data[file_name] = extracted_content
            except Exception as e:
                logger.error(f"Error processing Jira attachment {file_name} for issue {issue.key}: {str(e)}")
        return attachment_data
    except Exception as e:
        logger.error(f"Error fetching Jira attachments for issue {issue.key}: {str(e)}")
        return {}

async def fetch_jira_tickets():
    """Fetch new or updated Jira issues (bug type)."""
    try:
        ssl_verify = False
        logger.warning("SSL verification disabled for Jira due to certificate issues. This is insecure and should only be used for testing.")
        warnings.warn("Jira SSL verification disabled. This is insecure.", UserWarning)

        jira = JIRA(
            server=settings.JIRA_SERVER,
            basic_auth=(settings.JIRA_USERNAME, settings.JIRA_API_TOKEN),
            options={'verify': ssl_verify}
        )
        jql = 'issuetype = Bug AND (created >= -1d OR updated >= -1d) ORDER BY created DESC'
        issues = jira.search_issues(jql, maxResults=100)
        logger.info(f"Fetched {len(issues)} Jira issues")
        normalized_tickets = []

        for issue in issues:
            ticket_id = issue.key
            email = issue.fields.reporter.emailAddress if issue.fields.reporter else 'unknown@company.com'
            description = issue.fields.description or 'No description provided'
            priority = issue.fields.priority.name if issue.fields.priority else None
            team = issue.fields.project.name if issue.fields.project else None
            status = issue.fields.status.name
            resolution = issue.fields.resolution.name if issue.fields.resolution else None
            created_at = issue.fields.created
            updated_at = issue.fields.updated

            created_at = datetime.strptime(created_at, '%Y-%m-%dT%H:%M:%S.%f%z').replace(tzinfo=None)
            updated_at = datetime.strptime(updated_at, '%Y-%m-%dT%H:%M:%S.%f%z').replace(tzinfo=None)

            additional_info = await fetch_jira_attachments(jira, issue)

            normalized_tickets.append({
                "ticket_id": ticket_id,
                "email": email,
                "description": description,
                "status": 'resolved' if status.lower() in ['done', 'closed'] else 'new',
                "priority": priority,
                "team": team,
                "resolution": resolution,
                "created_at": created_at,
                "updated_at": updated_at,
                "source": "jira",
                "additional_info": additional_info
            })

        return normalized_tickets
    except Exception as e:
        logger.error(f"Error fetching Jira tickets: {str(e)}", exc_info=True)
        return []

def get_ms_graph_access_token():
    """Obtain an access token for Microsoft Graph API."""
    try:
        client_id = settings.MS_GRAPH_CLIENT_ID
        client_secret = settings.MS_GRAPH_CLIENT_SECRET
        tenant_id = settings.MS_GRAPH_TENANT_ID
        authority = f"https://login.microsoftonline.com/{tenant_id}"
        scope = ["https://graph.microsoft.com/.default"]

        app = msal.ConfidentialClientApplication(
            client_id,
            authority=authority,
            client_credential=client_secret
        )
        result = app.acquire_token_for_client(scopes=scope)

        if "access_token" in result:
            return result["access_token"]
        else:
            logger.error(f"Failed to obtain MS Graph access token: {result.get('error_description')}")
            return None
    except Exception as e:
        logger.error(f"Error obtaining MS Graph access token: {str(e)}", exc_info=True)
        return None

async def fetch_outlook_attachments(email_id, access_token):
    """Fetch and extract content from Outlook email attachments."""
    try:
        url = f"https://graph.microsoft.com/v1.0/users/{quote(settings.MS_GRAPH_MAILBOX)}/messages/{email_id}/attachments"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json"
        }
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            logger.error(f"Failed to fetch Outlook attachments for email {email_id}: {response.status_code}")
            return {}

        attachments = response.json().get('value', [])
        attachment_data = {}
        for attachment in attachments:
            if attachment.get('contentType') == 'message/rfc822':
                continue
            file_name = attachment.get('name', '')
            content_type = attachment.get('contentType', '')
            content_bytes = base64.b64decode(attachment.get('contentBytes', ''))
            try:
                content = await extractor.extract_content(
                    file_content=content_bytes,
                    filename=file_name,
                    content_type=content_type
                )
                if content:
                    attachment_data[file_name] = content
            except Exception as e:
                logger.error(f"Error processing Outlook attachment {file_name}: {str(e)}")
        return attachment_data
    except Exception as e:
        logger.error(f"Error fetching Outlook attachments for email {email_id}: {str(e)}")
        return {}

async def fetch_outlook_tickets():
    """Fetch emails from a specific mailbox and treat them as tickets."""
    try:
        access_token = get_ms_graph_access_token()
        if not access_token:
            return []

        mailbox = settings.MS_GRAPH_MAILBOX
        date_filter = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%SZ')
        logger.info(f"Constructed Outlook filter: receivedDateTime ge {date_filter}")
        url = f"https://graph.microsoft.com/v1.0/users/{quote(mailbox)}/messages?$filter=receivedDateTime ge {date_filter}&$top=100"
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json"
        }
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            logger.error(f"Failed to fetch Outlook emails: {response.status_code} - {response.text}")
            return []

        emails = response.json().get('value', [])
        logger.info(f"Fetched {len(emails)} emails from Outlook")
        normalized_tickets = []

        for email in emails:
            ticket_id = email.get('id')
            email_from = email.get('from', {}).get('emailAddress', {}).get('address', 'unknown@company.com')
            subject = email.get('subject', 'No subject')
            html_body = email.get('body', {}).get('content', 'No content')
            received_at = email.get('receivedDateTime')

            soup = BeautifulSoup(html_body, "html.parser")
            plain_text = soup.get_text(separator=" ", strip=True)
            description = f"Subject: {subject}\n\n{plain_text}"

            created_at = datetime.strptime(received_at, '%Y-%m-%dT%H:%M:%S%z').replace(tzinfo=None)
            updated_at = created_at

            additional_info = await fetch_outlook_attachments(ticket_id, access_token)

            normalized_tickets.append({
                "ticket_id": ticket_id,
                "email": email_from,
                "description": description,
                "status": "new",
                "priority": None,
                "team": None,
                "resolution": None,
                "created_at": created_at,
                "updated_at": updated_at,
                "source": "outlook",
                "additional_info": additional_info
            })

        return normalized_tickets
    except Exception as e:
        logger.error(f"Error fetching Outlook tickets: {str(e)}", exc_info=True)
        return []

def save_tickets_to_db(tickets):
    """Save normalized tickets to the database, avoiding duplicates, and send initial emails."""
    db = SessionLocal()
    try:
        for ticket_data in tickets:
            existing_ticket = db.query(NewTicket).filter_by(ticket_id=ticket_data["ticket_id"]).first()
            if existing_ticket:
                logger.info(f"Ticket {ticket_data['ticket_id']} already exists, skipping")
                continue

            ticket = NewTicket(
                ticket_id=ticket_data["ticket_id"],
                email=ticket_data["email"],
                description=ticket_data["description"],
                status=ticket_data["status"],
                priority=ticket_data["priority"],
                team=ticket_data["team"],
                resolution=ticket_data["resolution"],
                created_at=ticket_data["created_at"],
                updated_at=ticket_data["updated_at"],
                source=ticket_data["source"],
                additional_info=ticket_data["additional_info"]
            )
            db.add(ticket)
            db.flush()  # Ensure ticket is saved to get ID
            db.commit()

            # Send initial email
            if ticket_data["email"] != 'unknown@company.com':
                success = mailgun_client.send_initial_email(
                    ticket_id=ticket_data["ticket_id"],
                    recipient_email=ticket_data["email"],
                    ticket_description=ticket_data["description"]
                )
                if not success:
                    logger.warning(f"Failed to send initial email for ticket {ticket_data['ticket_id']}")
        logger.info(f"Saved {len(tickets)} tickets to database")
    except Exception as e:
        logger.error(f"Error saving tickets to database: {str(e)}", exc_info=True)
        db.rollback()
    finally:
        db.close()

async def fetch_all_tickets():
    """Fetch tickets from all sources, save to database, and send initial emails."""
    try:
        servicenow_tickets = await fetch_servicenow_tickets()
        jira_tickets = await fetch_jira_tickets()
        outlook_tickets = await fetch_outlook_tickets()

        all_tickets = servicenow_tickets + jira_tickets + outlook_tickets
        logger.info(f"Total tickets fetched: {len(all_tickets)}")

        save_tickets_to_db(all_tickets)
        return {"status": "success", "message": f"Fetched and saved {len(all_tickets)} tickets"}
    except Exception as e:
        logger.error(f"Error in fetch_all_tickets: {str(e)}", exc_info=True)
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    result = asyncio.run(fetch_all_tickets())
    print(result)