import os
import hmac
import hashlib
import logging
import json
from datetime import datetime
from typing import Dict, Any
import requests
from core.config import settings
from core.database import SessionLocal
from models.models import EmailInteraction

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('..', 'logs', 'mailgun.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class MailgunClient:
    def __init__(self):
        self.api_key = settings.MAILGUN_API_KEY
        self.domain = settings.MAILGUN_DOMAIN
        self.from_email = settings.MAILGUN_FROM_EMAIL
        self.webhook_signing_key = settings.MAILGUN_WEBHOOK_SIGNING_KEY
        self.api_url = f"https://api.mailgun.net/v3/{self.domain}/messages"
        self.ca_cert_path = os.path.join(os.path.dirname(__file__), '..', 'certificates', 'Zscaler Root CA.crt')
        if not os.path.exists(self.ca_cert_path):
            logger.warning(f"CA certificate not found at {self.ca_cert_path}. Disabling SSL verification (insecure).")
            self.ca_cert_path = None

    def send_initial_email(self, ticket_id: str, recipient_email: str, ticket_description: str) -> bool:
        """Send an initial email to the user for a ticket."""
        try:
            subject = f"Ticket {ticket_id} Processed"
            text = (
                f"Dear User,\n\nYour ticket {ticket_id} has been received:\n\n"
                f"{ticket_description}\n\nPlease reply with any additional details or questions."
            )
            data = {
                "from": self.from_email,
                "to": recipient_email,
                "subject": subject,
                "text": text
            }
            response = requests.post(
                self.api_url,
                auth=("api", self.api_key),
                data=data,
                verify=self.ca_cert_path if self.ca_cert_path else False
            )
            response.raise_for_status()
            logger.info(f"Sent initial email for ticket {ticket_id} to {recipient_email}")
            return True
        except Exception as e:
            logger.error(f"Error sending initial email for ticket {ticket_id}: {str(e)}", exc_info=True)
            return False

    def send_followup_email(self, ticket_id: str, recipient_email: str, additional_info_needed: str) -> bool:
        """Send a follow-up email to the user for a ticket."""
        try:
            subject = f"Follow-up: Ticket {ticket_id} Needs Additional Information"
            text = (
                f"Dear User,\n\nWe are processing your ticket {ticket_id}. "
                f"{additional_info_needed}\n\nPlease reply to this email with the requested details."
            )
            data = {
                "from": self.from_email,
                "to": recipient_email,
                "subject": subject,
                "text": text
            }
            response = requests.post(
                self.api_url,
                auth=("api", self.api_key),
                data=data,
                verify=self.ca_cert_path if self.ca_cert_path else False
            )
            response.raise_for_status()
            logger.info(f"Sent follow-up email for ticket {ticket_id} to {recipient_email}")

            # Save to EmailInteraction
            db = SessionLocal()
            try:
                interaction = EmailInteraction(
                    ticket_id=ticket_id,
                    email_type="followup",
                    sender=self.from_email,
                    recipient=recipient_email,
                    subject=subject,
                    body=text,
                    sent_at=datetime.utcnow(),
                    additional_info={}
                )
                db.add(interaction)
                db.commit()
                logger.info(f"Logged follow-up email for ticket {ticket_id}")
                return True
            except Exception as e:
                logger.error(f"Error logging follow-up email for ticket {ticket_id}: {str(e)}", exc_info=True)
                db.rollback()
                return False
            finally:
                db.close()
        except Exception as e:
            logger.error(f"Error sending follow-up email for ticket {ticket_id}: {str(e)}", exc_info=True)
            return False

    def verify_webhook(self, timestamp: str, token: str, signature: str) -> bool:
        """Verify the Mailgun webhook signature."""
        try:
            if not all([timestamp, token, signature]):
                logger.error("Missing timestamp, token, or signature in webhook data")
                return False
            hmac_digest = hmac.new(
                key=self.webhook_signing_key.encode('ascii'),
                msg=f"{timestamp}{token}".encode('ascii'),
                digestmod=hashlib.sha256
            ).hexdigest()
            return hmac.compare_digest(hmac_digest, signature)
        except Exception as e:
            logger.error(f"Error verifying webhook signature: {str(e)}", exc_info=True)
            return False

    def handle_webhook(self, webhook_data: dict) -> bool:
        """Handle incoming webhook data for user replies."""
        try:
            logger.debug(f"Received webhook data: {json.dumps(webhook_data, indent=2)}")
            signature_data = webhook_data.get('signature', {})
            timestamp = signature_data.get('timestamp')
            token = signature_data.get('token')
            signature = signature_data.get('signature')
            if not self.verify_webhook(timestamp, token, signature):
                logger.error("Invalid or missing webhook signature")
                return False

            event_data = webhook_data.get('event-data', {})
            recipient = event_data.get('recipient', 'Unknown recipient')
            sender = event_data.get('sender')
            if not sender:
                logger.warning("No sender provided in webhook event-data, likely a test webhook. Accepting without processing.")
                return True  # Accept test webhook without processing
            message_headers = event_data.get('message', {}).get('headers', {})
            subject = message_headers.get('subject', 'No subject')
            body = event_data.get('stripped-text', 'No content')

            ticket_id = None
            if subject and 'Ticket' in subject:
                parts = subject.split()
                for part in parts:
                    if part.startswith('INC') or part.startswith('PROJ') or len(part) > 10:
                        ticket_id = part
                        break

            if not ticket_id:
                logger.warning(f"No ticket ID found in subject: {subject}. Attempting to match by sender email: {sender}")
                db = SessionLocal()
                try:
                    from models.models import NewTicket
                    ticket = db.query(NewTicket).filter_by(email=sender).order_by(NewTicket.created_at.desc()).first()
                    if ticket:
                        ticket_id = ticket.ticket_id
                    else:
                        logger.error(f"No matching ticket found for sender: {sender}")
                        return False
                finally:
                    db.close()

            db = SessionLocal()
            try:
                interaction = EmailInteraction(
                    ticket_id=ticket_id,
                    email_type="reply",
                    sender=sender,
                    recipient=recipient,
                    subject=subject,
                    body=body,
                    sent_at=datetime.utcnow(),
                    additional_info={"raw_webhook": webhook_data}
                )
                db.add(interaction)
                db.commit()
                logger.info(f"Logged user reply for ticket {ticket_id} from {sender}")
                
                # Update ticket status if reply indicates resolution
                ticket = db.query(NewTicket).filter_by(ticket_id=ticket_id).first()
                if ticket:
                    ticket.updated_at = datetime.utcnow()
                    if "resolved" in body.lower():
                        ticket.status = "resolved"
                        ticket.resolution = body
                    db.commit()
                    logger.info(f"Updated ticket {ticket_id} based on reply")
                return True
            except Exception as e:
                logger.error(f"Error logging webhook reply for ticket {ticket_id}: {str(e)}", exc_info=True)
                db.rollback()
                return False
            finally:
                db.close()
        except Exception as e:
            logger.error(f"Error handling webhook: {str(e)}", exc_info=True)
            return False