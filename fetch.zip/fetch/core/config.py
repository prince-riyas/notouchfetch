import os
from dotenv import load_dotenv

load_dotenv()

# Get the absolute path to the fetch directory
FETCH_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

class Settings:
    SNOW_API_URL = os.getenv("SNOW_API_URL")
    SNOW_AUTH_USERNAME = os.getenv("SNOW_AUTH_USERNAME")
    SNOW_AUTH_PASSWORD = os.getenv("SNOW_AUTH_PASSWORD")
    JIRA_SERVER = os.getenv("JIRA_SERVER")
    JIRA_USERNAME = os.getenv("JIRA_USERNAME")
    JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")
    MS_GRAPH_CLIENT_ID = os.getenv("MS_GRAPH_CLIENT_ID")
    MS_GRAPH_CLIENT_SECRET = os.getenv("MS_GRAPH_CLIENT_SECRET")
    MS_GRAPH_TENANT_ID = os.getenv("MS_GRAPH_TENANT_ID")
    MS_GRAPH_MAILBOX = os.getenv("MS_GRAPH_MAILBOX")
    DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{os.path.join(FETCH_DIR, 'tickets.db')}")
    LOG_FILE = os.getenv("LOG_FILE", "logs/fetch_tickets.log")
    AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
    AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
    AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
    AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")
    AZURE_OPENAI_EMBED_API_ENDPOINT = os.getenv("AZURE_OPENAI_EMBED_API_ENDPOINT")
    AZURE_OPENAI_EMBED_API_KEY = os.getenv("AZURE_OPENAI_EMBED_API_KEY")
    AZURE_OPENAI_EMBED_VERSION = os.getenv("AZURE_OPENAI_EMBED_VERSION")
    AZURE_OPENAI_EMBED_MODEL = os.getenv("AZURE_OPENAI_EMBED_MODEL")
    MAILGUN_API_KEY = os.getenv("MAILGUN_API_KEY")
    MAILGUN_DOMAIN = os.getenv("MAILGUN_DOMAIN")
    MAILGUN_FROM_EMAIL = os.getenv("MAILGUN_FROM_EMAIL")
    MAILGUN_WEBHOOK_SIGNING_KEY = os.getenv("MAILGUN_WEBHOOK_SIGNING_KEY")

settings = Settings()

required_settings = [
    "SNOW_API_URL", "SNOW_AUTH_USERNAME", "SNOW_AUTH_PASSWORD",
    "JIRA_SERVER", "JIRA_USERNAME", "JIRA_API_TOKEN",
    "MS_GRAPH_CLIENT_ID", "MS_GRAPH_CLIENT_SECRET", "MS_GRAPH_TENANT_ID", "MS_GRAPH_MAILBOX",
    "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_API_VERSION", "AZURE_OPENAI_DEPLOYMENT",
    "AZURE_OPENAI_EMBED_API_ENDPOINT", "AZURE_OPENAI_EMBED_API_KEY", "AZURE_OPENAI_EMBED_VERSION", "AZURE_OPENAI_EMBED_MODEL",
    "MAILGUN_API_KEY", "MAILGUN_DOMAIN", "MAILGUN_FROM_EMAIL", "MAILGUN_WEBHOOK_SIGNING_KEY"
]
for setting in required_settings:
    if not getattr(settings, setting):
        raise ValueError(f"Missing required environment variable: {setting}")