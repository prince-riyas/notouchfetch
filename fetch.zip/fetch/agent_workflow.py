import os
import sys
import logging
import json
import asyncio
from typing import Dict, Any, TypedDict, Optional
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from core.config import settings
from core.database import SessionLocal
from models.models import NewTicket, EmailInteraction, Analysis
from langgraph.graph import StateGraph, END
from apscheduler.schedulers.background import BackgroundScheduler
from rag.rag_processor import RAGProcessor
from mailgun.mailgun_client import MailgunClient
from main import fetch_all_tickets

# Add fetch/ to sys.path to ensure scripts/ is importable
sys.path.append(os.path.abspath(os.path.dirname(__file__)))
from scripts.index_documents import DocumentIndexer
from scripts.export_tickets import export_tickets

# Configure logging
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('logs', 'agent_workflow.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# State definition
class TicketState(TypedDict):
    ticket_id: str
    ticket_data: Dict[str, Any]
    rag_result: Optional[Dict[str, Any]]
    email_sent: bool
    follow_up_sent: bool
    reply_received: bool
    resolution_final: bool
    index_updated: bool
    tickets_exported: bool

# Nodes
async def update_index(state: TicketState, db: Session) -> TicketState:
    """Update the FAISS index by running index_documents."""
    if state.get("index_updated", False):
        return state
    try:
        indexer = DocumentIndexer()
        await indexer.index_documents(db)
        state["index_updated"] = True
        logger.info("Updated FAISS index")
    except Exception as e:
        logger.error(f"Error updating FAISS index: {str(e)}")
    return state

def export_tickets_node(state: TicketState) -> TicketState:
    """Export tickets to Excel by running extract_tickets."""
    if state.get("tickets_exported", False):
        return state
    try:
        export_tickets()
        state["tickets_exported"] = True
        logger.info("Exported tickets to tickets.xlsx")
    except Exception as e:
        logger.error(f"Error exporting tickets: {str(e)}")
    return state

async def fetch_tickets(state: TicketState, db: Session) -> TicketState:
    """Fetch new tickets from all sources."""
    try:
        result = await fetch_all_tickets()
        if result["status"] != "success":
            logger.warning(f"Failed to fetch tickets: {result['message']}")
            return state

        # Fetch one new ticket
        ticket = db.query(NewTicket).filter(NewTicket.status == "new").first()
        if not ticket:
            logger.info("No new tickets found")
            state["ticket_id"] = ""
            return state

        reply = db.query(EmailInteraction).filter(
            EmailInteraction.ticket_id == ticket.ticket_id,
            EmailInteraction.email_type == "reply"
        ).first()

        state["ticket_id"] = ticket.ticket_id
        state["ticket_data"] = {
            "ticket_id": ticket.ticket_id,
            "description": ticket.description,
            "ticket_additional_info": "\n".join(str(v) for v in ticket.additional_info.values()) if ticket.additional_info else "",
            "reply": reply.body if reply else "",
            "reply_additional_info": "\n".join(str(v) for v in reply.additional_info.values()) if reply and reply.additional_info else "",
            "email": ticket.email
        }
        state["reply_received"] = bool(reply)
        logger.info(f"Fetched ticket {ticket.ticket_id}")
    except Exception as e:
        logger.error(f"Error fetching tickets: {str(e)}")
    return state

def initial_rag_analysis(state: TicketState, db: Session) -> TicketState:
    """Perform initial RAG analysis to check if resolution is sufficient."""
    if not state["ticket_id"]:
        return state

    try:
        rag_processor = RAGProcessor()
        rag_processor.load_or_create_vector_store(db)
        state["rag_result"] = rag_processor.process_rag(state["ticket_data"])
        rag_processor.save_analysis(state["rag_result"], db)
        logger.info(f"Performed RAG analysis for ticket {state['ticket_id']}")
    except Exception as e:
        logger.error(f"Error in RAG analysis for ticket {state['ticket_id']}: {str(e)}")
    return state

def send_initial_email(state: TicketState, db: Session) -> TicketState:
    """Send initial confirmation email."""
    if not state["ticket_id"] or state["email_sent"]:
        return state

    try:
        mailgun_client = MailgunClient()
        state["email_sent"] = mailgun_client.send_initial_email(
            ticket_id=state["ticket_id"],
            recipient_email=state["ticket_data"]["email"],
            ticket_description=state["ticket_data"]["description"]
        )
        logger.info(f"Sent initial email for ticket {state['ticket_id']}")
    except Exception as e:
        logger.error(f"Error sending initial email for ticket {state['ticket_id']}: {str(e)}")
    return state

def decide_action_node(state: TicketState) -> TicketState:
    """Node to decide whether to finalize resolution or send follow-up."""
    if not state["ticket_id"]:
        logger.info("No ticket to process, exiting workflow")
        state["resolution_final"] = True  # Mark as final to exit
    else:
        logger.info(f"Deciding action for ticket {state['ticket_id']}")
    return state

def decide_action(state: TicketState) -> str:
    """Routing function to determine next action."""
    if not state["ticket_id"] or state["resolution_final"]:
        logger.info("No ticket or workflow complete, routing to end")
        return "end"

    if not state["rag_result"]:
        logger.info(f"No RAG result for ticket {state['ticket_id']}, routing to send_followup")
        return "send_followup"

    rag_result = state["rag_result"]
    if (rag_result.get("confidence") == "High" and
            rag_result.get("proposed_resolution") and
            rag_result.get("recommended_resolution", {}).get("priority") and
            rag_result.get("recommended_resolution", {}).get("resolution")):
        logger.info(f"High confidence for ticket {state['ticket_id']}, routing to finalize_resolution")
        return "finalize_resolution"
    logger.info(f"Low/Medium confidence for ticket {state['ticket_id']}, routing to send_followup")
    return "send_followup"

def send_followup_email(state: TicketState, db: Session) -> TicketState:
    """Send follow-up email with specific questions."""
    if not state["ticket_id"] or state["follow_up_sent"]:
        return state

    try:
        mailgun_client = MailgunClient()
        questions = state["rag_result"].get("follow_up_questions", ["Please provide more details about the issue."])
        additional_info_needed = "\n".join(f"- {q}" for q in questions)
        state["follow_up_sent"] = mailgun_client.send_followup_email(
            ticket_id=state["ticket_id"],
            recipient_email=state["ticket_data"]["email"],
            additional_info_needed=additional_info_needed
        )
        logger.info(f"Sent follow-up email for ticket {state['ticket_id']}")
    except Exception as e:
        logger.error(f"Error sending follow-up email for ticket {state['ticket_id']}: {str(e)}")
    return state

def wait_for_reply(state: TicketState, db: Session) -> TicketState:
    """Check for new user replies."""
    if not state["follow_up_sent"] or state["reply_received"]:
        return state

    try:
        reply = db.query(EmailInteraction).filter(
            EmailInteraction.ticket_id == state["ticket_id"],
            EmailInteraction.email_type == "reply",
            EmailInteraction.sent_at > datetime.utcnow() - timedelta(hours=24)
        ).first()

        if reply:
            state["ticket_data"]["reply"] = reply.body
            state["ticket_data"]["reply_additional_info"] = "\n".join(str(v) for v in reply.additional_info.values()) if reply.additional_info else ""
            state["reply_received"] = True
            logger.info(f"Received reply for ticket {state['ticket_id']}")
    except Exception as e:
        logger.error(f"Error checking reply for ticket {state['ticket_id']}: {str(e)}")
    return state

def finalize_resolution(state: TicketState, db: Session) -> TicketState:
    """Finalize resolution and close ticket."""
    if not state["rag_result"]:
        return state

    try:
        ticket = db.query(NewTicket).filter_by(ticket_id=state["ticket_id"]).first()
        if ticket:
            ticket.status = "resolved"
            ticket.resolution = state["rag_result"]["proposed_resolution"]
            db.commit()
            logger.info(f"Closed ticket {state['ticket_id']}")
        state["resolution_final"] = True
    except Exception as e:
        logger.error(f"Error finalizing ticket {state['ticket_id']}: {str(e)}")
    return state

# Graph definition
def build_graph():
    graph = StateGraph(TicketState)

    graph.add_node("update_index", lambda state: asyncio.run(update_index(state, SessionLocal())))
    graph.add_node("export_tickets", export_tickets_node)
    graph.add_node("fetch_tickets", lambda state: asyncio.run(fetch_tickets(state, SessionLocal())))
    graph.add_node("initial_rag_analysis", lambda state: initial_rag_analysis(state, SessionLocal()))
    graph.add_node("send_initial_email", lambda state: send_initial_email(state, SessionLocal()))
    graph.add_node("decide_action", decide_action_node)
    graph.add_node("send_followup_email", lambda state: send_followup_email(state, SessionLocal()))
    graph.add_node("wait_for_reply", lambda state: wait_for_reply(state, SessionLocal()))
    graph.add_node("finalize_resolution", lambda state: finalize_resolution(state, SessionLocal()))

    graph.set_entry_point("update_index")
    graph.add_edge("update_index", "export_tickets")
    graph.add_edge("export_tickets", "fetch_tickets")
    graph.add_edge("fetch_tickets", "initial_rag_analysis")
    graph.add_edge("initial_rag_analysis", "send_initial_email")
    graph.add_edge("send_initial_email", "decide_action")

    graph.add_conditional_edges(
        "decide_action",
        decide_action,
        {
            "send_followup": "send_followup_email",
            "finalize_resolution": "finalize_resolution",
            "end": END
        }
    )
    graph.add_edge("send_followup_email", "wait_for_reply")
    graph.add_edge("wait_for_reply", "initial_rag_analysis")
    graph.add_edge("finalize_resolution", END)

    return graph.compile()  # No recursion_limit

def run_workflow():
    graph = build_graph()
    state = {
        "ticket_id": "",
        "ticket_data": {},
        "rag_result": None,
        "email_sent": False,
        "follow_up_sent": False,
        "reply_received": False,
        "resolution_final": False,
        "index_updated": False,
        "tickets_exported": False
    }
    result = graph.invoke(state)
    logger.info(f"Workflow completed with state: {json.dumps(result, default=str)}")

def main():
    # Schedule workflow every 10 minutes
    scheduler = BackgroundScheduler()
    scheduler.add_job(run_workflow, 'interval', minutes=2)
    scheduler.start()
    
    try:
        while True:
            pass
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()

if __name__ == "__main__":
    main()