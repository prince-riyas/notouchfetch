import logging
import os
from fastapi import FastAPI, Request, HTTPException
from mailgun.mailgun_client import MailgunClient
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('..', 'logs', 'webhook.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

app = FastAPI()
mailgun_client = MailgunClient()

@app.post("/webhook/mailgun")
async def handle_mailgun_webhook(request: Request):
    """Handle incoming Mailgun webhooks."""
    try:
        webhook_data = await request.json()
        success = mailgun_client.handle_webhook(webhook_data)
        if not success:
            raise HTTPException(status_code=400, detail="Failed to process webhook")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Error processing webhook: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)