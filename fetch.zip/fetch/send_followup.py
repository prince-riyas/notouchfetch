import os
from sqlalchemy.orm import Session
from mailgun.mailgun_client import MailgunClient
from models.models import NewTicket, EmailInteraction
from core.database import SessionLocal
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('..', 'logs', 'followup.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def send_followup_emails():
    """Send follow-up emails for tickets needing additional information."""
    mailgun_client = MailgunClient()
    db = SessionLocal()
    try:
        tickets = db.query(NewTicket).filter(NewTicket.status == "new").all()
        if not tickets:
            logger.info("No tickets with status='new' found.")
            return

        for ticket in tickets:
            recipient_email = ticket.email or "Prince.PR@ust.com"
            if not recipient_email:
                logger.warning(f"Skipping ticket {ticket.ticket_id}: No valid email address.")
                continue

            followup_sent = db.query(EmailInteraction).filter(
                EmailInteraction.ticket_id == ticket.ticket_id,
                EmailInteraction.email_type == "followup"
            ).first()
            if followup_sent:
                logger.info(f"Skipping ticket {ticket.ticket_id}: Follow-up email already sent.")
                continue

            if not ticket.additional_info or not any(ticket.additional_info.values()):
                additional_info_needed = (
                    "Please provide any relevant screenshots or documents to help us process your ticket."
                )
                success = mailgun_client.send_followup_email(
                    ticket_id=ticket.ticket_id,
                    recipient_email=recipient_email,
                    additional_info_needed=additional_info_needed
                )
                if success:
                    logger.info(f"Follow-up email sent for ticket {ticket.ticket_id} to {recipient_email}")
                else:
                    logger.warning(f"Failed to send follow-up email for ticket {ticket.ticket_id}")
            else:
                logger.info(f"Skipping ticket {ticket.ticket_id}: additional_info is populated.")
    except Exception as e:
        logger.error(f"Error sending follow-up emails: {str(e)}", exc_info=True)
    finally:
        db.close()

if __name__ == "__main__":
    send_followup_emails()