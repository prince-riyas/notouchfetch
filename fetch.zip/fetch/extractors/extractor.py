import os
import logging
import io
import base64
import json
from PIL import Image
from docx import Document
import pdfplumber
import pandas as pd
from pptx import Presentation
from bs4 import BeautifulSoup
from llama_index.llms.azure_openai import AzureOpenAI
from llama_index.core.base.llms.types import ChatMessage
from core.config import settings

# Configure logging
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('logs', 'extractor.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ContentType:
    PDF = "application/pdf"
    DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    PPT = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    TXT = "text/plain"
    JSON = "application/json"
    CSV = "text/csv"
    IMAGE_JPEG = "image/jpeg"
    IMAGE_PNG = "image/png"
    HTML = "text/html"
    XML = "application/xml"
    LOG = "text/x-log"
    UNKNOWN = "application/octet-stream"

class DocumentExtractor:
    def __init__(self):
        self.llm = AzureOpenAI(
            engine=settings.AZURE_OPENAI_DEPLOYMENT,
            model="gpt-4o",
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            temperature=0.0
        )

    async def extract_content(self, file_content: bytes, filename: str, content_type: str) -> str:
        """Extract content from a file based on its content type."""
        file_stream = io.BytesIO(file_content)
        try:
            if content_type == ContentType.PDF:
                with pdfplumber.open(file_stream) as pdf:
                    text = " ".join([page.extract_text() or "" for page in pdf.pages])
                    images = []
                    for page in pdf.pages:
                        for img in page.images:
                            try:
                                x0, y0, x1, y1 = img['x0'], img['y0'], img['x1'], img['y1']
                                pil_image = page.within_bbox((x0, y0, x1, y1)).to_image().original
                                image_text = await self._image_to_text(pil_image)
                                if image_text and image_text != 'no_data':
                                    images.append(image_text)
                            except Exception as e:
                                logger.error(f"Error processing PDF image in {filename}: {str(e)}")
                    return text + "\n" + "\n".join(images)

            elif content_type == ContentType.DOCX:
                doc = Document(file_stream)
                text = "\n".join([para.text for para in doc.paragraphs])
                images = []
                for rel in doc.part.rels.values():
                    if "image" in rel.target_ref:
                        try:
                            image = Image.open(io.BytesIO(rel.target_part.blob))
                            image_text = await self._image_to_text(image)
                            if image_text and image_text != 'no_data':
                                images.append(image_text)
                        except Exception as e:
                            logger.error(f"Error processing DOCX image in {filename}: {str(e)}")
                return text + "\n" + "\n".join(images)

            elif content_type == ContentType.XLSX:
                excel = pd.read_excel(file_stream, engine="openpyxl")
                return "\n\n".join([f"Sheet: {name}\n{df.to_string(index=False)}" 
                                  for name, df in pd.read_excel(file_stream, sheet_name=None).items()])

            elif content_type == ContentType.PPT:
                presentation = Presentation(file_stream)
                ppt_texts = []
                for slide in presentation.slides:
                    for shape in slide.shapes:
                        if shape.shape_type == 13:  # Picture
                            try:
                                image_text = await self._image_to_text(Image.open(io.BytesIO(shape.image.blob)))
                                if image_text and image_text != 'no_data':
                                    ppt_texts.append(image_text)
                            except Exception as e:
                                logger.error(f"Error processing PPT image in {filename}: {str(e)}")
                        elif hasattr(shape, 'has_text_frame') and shape.has_text_frame:
                            for paragraph in shape.text_frame.paragraphs:
                                for run in paragraph.runs:
                                    ppt_texts.append(run.text)
                return " ".join(ppt_texts)

            elif content_type in [ContentType.TXT, ContentType.LOG]:
                return file_stream.read().decode("utf-8", errors="replace")

            elif content_type == ContentType.JSON:
                try:
                    return json.dumps(json.load(file_stream), indent=2)
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to parse JSON in {filename}: {str(e)}")
                    return ""

            elif content_type == ContentType.CSV:
                return pd.read_csv(file_stream).to_string(index=False)

            elif content_type in [ContentType.IMAGE_JPEG, ContentType.IMAGE_PNG]:
                try:
                    return await self._image_to_text(Image.open(file_stream)) or ""
                except Exception as e:
                    logger.error(f"Error processing image {filename}: {str(e)}")
                    return ""

            elif content_type == ContentType.HTML:
                soup = BeautifulSoup(file_stream.read().decode("utf-8", errors="replace"), "html.parser")
                return soup.get_text(separator=" ")

            elif content_type == ContentType.XML:
                soup = BeautifulSoup(file_stream.read().decode("utf-8", errors="replace"), "xml")
                return soup.get_text(separator=" ")

            else:
                logger.warning(f"Unsupported content type {content_type} for {filename}")
                return ""

        except Exception as e:
            logger.error(f"Error processing {filename} (type: {content_type}): {str(e)}")
            return ""

    async def _image_to_text(self, image):
        """Extract text from images using Azure OpenAI."""
        try:
            buffer = io.BytesIO()
            image.save(buffer, format=image.format or "PNG")
            encoded_image = base64.b64encode(buffer.getvalue()).decode("ascii")

            messages = [
                {
                    "role": "system",
                    "content": """You are an advanced vision-based AI that extracts and describes images with extreme detail.
                    Extract ALL visible text, ensuring proper formatting.
                    Describe non-text elements (tables, diagrams, charts, forms, objects, handwriting, watermarks, etc.).
                    Return 'no_data' if the image contains only graphics with no extractable data."""
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": "Analyze and describe EVERYTHING in this image."
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{encoded_image}"
                            }
                        }
                    ]
                }
            ]

            response = await self.llm.achat([ChatMessage(**msg) for msg in messages])
            return response.message.content.strip()
        except Exception as e:
            logger.error(f"Error extracting image content: {str(e)}")
            return None

    def get_content_type(self, filename: str) -> str:
        """Determine content type from file extension."""
        file_extension = os.path.splitext(filename)[1].lower()
        extension_mapping = {
            '.pdf': ContentType.PDF,
            '.docx': ContentType.DOCX,
            '.xlsx': ContentType.XLSX,
            '.pptx': ContentType.PPT,
            '.txt': ContentType.TXT,
            '.json': ContentType.JSON,
            '.csv': ContentType.CSV,
            '.jpg': ContentType.IMAGE_JPEG,
            '.jpeg': ContentType.IMAGE_JPEG,
            '.png': ContentType.IMAGE_PNG,
            '.html': ContentType.HTML,
            '.xml': ContentType.XML,
            '.log': ContentType.LOG
        }
        return extension_mapping.get(file_extension, ContentType.UNKNOWN)