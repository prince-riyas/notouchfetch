import os
import logging
import json
from typing import Dict, Any
from sqlalchemy.orm import Session
from core.config import settings
from core.database import SessionLocal
from models.models import NewTicket, EmailInteraction
from langchain_community.vectorstores import FAISS
from langchain_openai import AzureOpenAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI
from langchain_core.output_parsers import StrOutputParser

# Configure logging
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('logs', 'rag_processor.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RAGProcessor:
    def __init__(self):
        self.embeddings = AzureOpenAIEmbeddings(
            azure_endpoint=settings.AZURE_OPENAI_EMBED_API_ENDPOINT,
            api_key=settings.AZURE_OPENAI_EMBED_API_KEY,
            api_version=settings.AZURE_OPENAI_EMBED_VERSION,
            model=settings.AZURE_OPENAI_EMBED_MODEL
        )
        self.llm = AzureChatOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_API_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
            deployment_name=settings.AZURE_OPENAI_DEPLOYMENT,
            temperature=0.0
        )
        self.vector_store = None
        self.vector_store_dir = os.path.join('data', 'faiss_index')

    def load_or_create_vector_store(self, db: Session):
        """Load the FAISS vector store (created by index_documents.py)."""
        if os.path.exists(os.path.join(self.vector_store_dir, 'index.faiss')):
            logger.info("Loading existing FAISS vector store")
            self.vector_store = FAISS.load_local(
                self.vector_store_dir,
                self.embeddings,
                allow_dangerous_deserialization=True
            )
        else:
            logger.error("FAISS vector store not found. Run index_documents.py first.")
            raise FileNotFoundError("FAISS vector store not found")

    def fetch_ticket_data(self, ticket_id: str, db: Session) -> Dict[str, Any]:
        """Fetch ticket data from NewTicket and EmailInteraction tables."""
        ticket = db.query(NewTicket).filter_by(ticket_id=ticket_id).first()
        if not ticket:
            logger.error(f"Ticket {ticket_id} not found")
            return {}

        data = {
            "ticket_id": ticket.ticket_id,
            "description": ticket.description,
            "ticket_additional_info": "",
            "reply": "",
            "reply_additional_info": ""
        }

        if ticket.additional_info:
            data["ticket_additional_info"] = "\n".join(str(v) for v in ticket.additional_info.values())

        reply = db.query(EmailInteraction).filter(
            EmailInteraction.ticket_id == ticket_id,
            EmailInteraction.email_type == "reply"
        ).first()
        if reply:
            data["reply"] = reply.body
            if reply.additional_info:
                data["reply_additional_info"] = "\n".join(str(v) for v in reply.additional_info.values())

        return data

    def process_rag(self, ticket_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process ticket data using RAG to generate analysis results."""
        if not ticket_data:
            return {}

        combined_text = f"{ticket_data['description']}\n{ticket_data['ticket_additional_info']}\n{ticket_data['reply']}\n{ticket_data['reply_additional_info']}".strip()
        if not combined_text:
            logger.warning(f"No content to process for ticket {ticket_data['ticket_id']}")
            return {}

        try:
            # Embed the input text
            query_embedding = self.embeddings.embed_query(combined_text)
            results = self.vector_store.similarity_search_with_score_by_vector(
                embedding=query_embedding,
                k=3
            )

            max_similarity = max([score for _, score in results], default=0.0)
            similar_tickets = [
                {
                    "source": doc.metadata.get("source", "unknown"),
                    "ticket_id": doc.metadata.get("ticket_id", ""),
                    "file_name": doc.metadata.get("file_name", ""),
                    "content": doc.page_content,
                    "score": float(score)
                }
                for doc, score in results
            ]

            # Determine confidence based on similarity score
            if max_similarity >= 0.8:
                confidence = "High"
            elif max_similarity >= 0.7:
                confidence = "Medium"
            else:
                confidence = "Low"

            # Generate predictions and follow-up questions
            prompt = ChatPromptTemplate.from_template(
                """Given the ticket description, ticket attachments, user reply, reply attachments, and similar documents, predict the priority, team, and resolution. If the confidence is low or resolution is unclear, suggest specific questions to ask the user for more information.
                Ticket Description: {description}
                Ticket Attachments: {ticket_additional_info}
                User Reply: {reply}
                Reply Attachments: {reply_additional_info}
                Similar Documents: {similar_tickets}
                Return only a valid JSON object with the following structure, without any additional text, markdown, or backticks:
                {{
                    "priority": "High/Medium/Low",
                    "team": "Team Name",
                    "resolution": "Resolution text",
                    "follow_up_questions": ["Question 1", "Question 2", ...]
                }}
                """
            )
            chain = prompt | self.llm | StrOutputParser()
            response = chain.invoke({
                "description": ticket_data["description"],
                "ticket_additional_info": ticket_data["ticket_additional_info"],
                "reply": ticket_data["reply"],
                "reply_additional_info": ticket_data["reply_additional_info"],
                "similar_tickets": json.dumps(similar_tickets, indent=2)
            })

            try:
                # Clean response to remove markdown or backticks
                response = response.strip()
                if response.startswith("```json") and response.endswith("```"):
                    response = response[7:-3].strip()
                elif response.startswith("```") and response.endswith("```"):
                    response = response[3:-3].strip()
                predictions = json.loads(response)
            except json.JSONDecodeError:
                logger.error(f"Failed to parse LLM response for ticket {ticket_data['ticket_id']}: {response}")
                predictions = {
                    "priority": None,
                    "team": None,
                    "resolution": None,
                    "follow_up_questions": ["Please provide more details about the issue."]
                }

            return {
                "ticket_id": ticket_data["ticket_id"],
                "type": "RAG",
                "proposed_resolution": predictions.get("resolution"),
                "updated_analysis": None,
                "confidence": confidence,
                "rag_insight_type": "Similarity",
                "rag_insight_content": json.dumps(similar_tickets),
                "recommended_resolution": {
                    "priority": predictions.get("priority"),
                    "team": predictions.get("team"),
                    "resolution": predictions.get("resolution")
                },
                "follow_up_questions": predictions.get("follow_up_questions", [])
            }
        except Exception as e:
            logger.error(f"Error processing RAG for ticket {ticket_data['ticket_id']}: {str(e)}")
            return {}

    def save_analysis(self, result: Dict[str, Any], db: Session):
        """Save analysis result to the database."""
        if not result:
            return

        from models.models import Analysis
        try:
            existing_analysis = db.query(Analysis).filter_by(ticket_id=result["ticket_id"]).first()
            if existing_analysis:
                logger.info(f"Analysis for ticket {result['ticket_id']} already exists, updating")
                existing_analysis.proposed_resolution = result["proposed_resolution"]
                existing_analysis.confidence = result["confidence"]
                existing_analysis.rag_insight_content = result["rag_insight_content"]
                existing_analysis.recommended_resolution = result["recommended_resolution"]
                db.commit()
                return

            analysis = Analysis(
                ticket_id=result["ticket_id"],
                type=result["type"],
                proposed_resolution=result["proposed_resolution"],
                updated_analysis=result["updated_analysis"],
                confidence=result["confidence"],
                rag_insight_type=result["rag_insight_type"],
                rag_insight_content=result["rag_insight_content"],
                recommended_resolution=result["recommended_resolution"]
            )
            db.add(analysis)
            db.commit()
            logger.info(f"Saved analysis for ticket {result['ticket_id']}")
        except Exception as e:
            logger.error(f"Error saving analysis for ticket {result['ticket_id']}: {str(e)}")
            db.rollback()