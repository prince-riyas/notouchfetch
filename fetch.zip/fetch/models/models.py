from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, JSON, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timezone, timedelta
from core.config import settings

Base = declarative_base()

# IST offset for created_at
IST_OFFSET = timedelta(hours=5, minutes=30)

class NewTicket(Base):
    __tablename__ = "new_tickets"

    id = Column(Integer, primary_key=True)
    ticket_id = Column(String(50), unique=True, nullable=False)  # Unique ID (e.g., SNOW sys_id, Jira key, email ID)
    email = Column(String(120), nullable=False)  # User email
    description = Column(Text, nullable=False)  # Ticket description
    status = Column(String(50), default="new")  # new, resolved
    priority = Column(String(50), nullable=True)  # e.g., High, Medium, Low
    team = Column(String(100), nullable=True)  # Assigned team/project
    resolution = Column(Text, nullable=True)  # Resolution provided
    source = Column(String(50), nullable=False)  # servicenow, jira, outlook
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    additional_info = Column(JSON, nullable=True)  # JSON field for attachment details

    def __repr__(self):
        return f"<NewTicket ticket_id={self.ticket_id} source={self.source}>"

class EmailInteraction(Base):
    __tablename__ = "email_interactions"

    id = Column(Integer, primary_key=True)
    ticket_id = Column(String(50), ForeignKey("new_tickets.ticket_id"), nullable=False)
    email_type = Column(String(50), nullable=False)  # initial, followup, reply
    sender = Column(String(120), nullable=False)  # From email
    recipient = Column(String(120), nullable=False)  # To email
    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)
    sent_at = Column(DateTime, default=datetime.utcnow)
    additional_info = Column(JSON, nullable=True)  # For reply content or metadata

    def __repr__(self):
        return f"<EmailInteraction ticket_id={self.ticket_id} email_type={self.email_type}>"

class Analysis(Base):
    __tablename__ = "analysis"

    id = Column(Integer, primary_key=True)
    ticket_id = Column(String(50), ForeignKey("new_tickets.ticket_id", ondelete="CASCADE"), nullable=False)
    type = Column(String(20), nullable=False)
    proposed_resolution = Column(Text)
    updated_analysis = Column(Text)
    confidence = Column(String(20), nullable=False)
    rag_insight_type = Column(String(20), nullable=False)
    rag_insight_content = Column(Text, nullable=False)
    recommended_resolution = Column(JSON)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc) + IST_OFFSET)

    def __repr__(self):
        return f"<Analysis ticket_id={self.ticket_id} type={self.type}>"

# Initialize database
engine = create_engine(settings.DATABASE_URL, echo=False)
Base.metadata.create_all(engine)

# Session factory
SessionLocal = sessionmaker(bind=engine)