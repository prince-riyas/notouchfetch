import os
import json
import logging
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pandas as pd
from sqlalchemy.orm import Session
from models.models import NewTicket, EmailInteraction
from core.database import SessionLocal
from core.config import settings
from langchain_community.vectorstores import FAISS
from langchain_openai import AzureOpenAIEmbeddings
from extractors.extractor import DocumentExtractor, ContentType
from PyPDF2 import PdfReader
from docx import Document
from pptx import Presentation
import asyncio

# Configure logging
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('logs', 'index_documents.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DocumentIndexer:
    def __init__(self):
        self.embeddings = AzureOpenAIEmbeddings(
            azure_endpoint=settings.AZURE_OPENAI_EMBED_API_ENDPOINT,
            api_key=settings.AZURE_OPENAI_EMBED_API_KEY,
            api_version=settings.AZURE_OPENAI_EMBED_VERSION,
            model=settings.AZURE_OPENAI_EMBED_MODEL
        )
        self.extractor = DocumentExtractor()
        # Use absolute path relative to scripts/
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.data_dir = os.path.join(self.script_dir, 'data')
        self.vector_store_dir = os.path.join(self.data_dir, 'faiss_index')

    async def index_documents(self, db: Session):
        documents = []
        metadatas = []

        # 1. Index NewTicket and EmailInteraction
        tickets = db.query(NewTicket).all()
        for ticket in tickets:
            text = ticket.description
            if ticket.additional_info:
                text += "\n" + "\n".join(str(v) for v in ticket.additional_info.values())
            reply = db.query(EmailInteraction).filter(
                EmailInteraction.ticket_id == ticket.ticket_id,
                EmailInteraction.email_type == "reply"
            ).first()
            if reply:
                text += "\n" + reply.body
                if reply.additional_info:
                    text += "\n" + "\n".join(str(v) for v in reply.additional_info.values())
            documents.append(text)
            metadatas.append({"source": "database", "ticket_id": ticket.ticket_id})
            logger.info(f"Indexed ticket {ticket.ticket_id}")

        # 2. Index files in data directory
        for file_name in os.listdir(self.data_dir):
            file_path = os.path.join(self.data_dir, file_name)
            content_type = self.extractor.get_content_type(file_name)
            if content_type == ContentType.UNKNOWN:
                logger.warning(f"Skipping unsupported file {file_name}")
                continue
            try:
                with open(file_path, 'rb') as f:
                    file_content = f.read()
                text = await self.extractor.extract_content(file_content, file_name, content_type)
                if text and text != "no_data":
                    documents.append(text)
                    metadatas.append({"source": content_type, "file_name": file_name})
                    logger.info(f"Indexed {content_type} file {file_name}")
            except Exception as e:
                logger.error(f"Error indexing {file_name}: {str(e)}")

        # Create or update FAISS index
        if documents:
            vector_store = FAISS.from_texts(
                texts=documents,
                embedding=self.embeddings,
                metadatas=metadatas
            )
            os.makedirs(self.vector_store_dir, exist_ok=True)
            vector_store.save_local(self.vector_store_dir)
            logger.info("Saved FAISS vector store")
        else:
            logger.warning("No documents to index")
            vector_store = FAISS.from_texts(
                texts=["placeholder"],
                embedding=self.embeddings,
                metadatas=[{"source": "placeholder", "ticket_id": "placeholder"}]
            )
            vector_store.save_local(self.vector_store_dir)

def main():
    os.makedirs('logs', exist_ok=True)
    db = SessionLocal()
    try:
        indexer = DocumentIndexer()
        asyncio.run(indexer.index_documents(db))
    finally:
        db.close()

if __name__ == "__main__":
    main()