import os
import logging
import sys
from sqlalchemy.orm import Session
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from core.database import SessionLocal
from models.models import NewTicket
from rag.rag_processor import RAGProcessor

# Configure logging
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join('logs', 'analysis.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def generate_analysis():
    db = SessionLocal()
    rag_processor = RAGProcessor()
    try:
        rag_processor.load_or_create_vector_store(db)
        tickets = db.query(NewTicket).filter(NewTicket.status == "new").all()
        if not tickets:
            logger.info("No tickets with status='new' found.")
            return

        for ticket in tickets:
            ticket_data = rag_processor.fetch_ticket_data(ticket.ticket_id, db)
            if not ticket_data:
                logger.warning(f"Skipping ticket {ticket.ticket_id}: No data found")
                continue

            result = rag_processor.process_rag(ticket_data)
            if result:
                rag_processor.save_analysis(result, db)
                logger.info(f"Processed analysis for ticket {ticket.ticket_id}")
            else:
                logger.warning(f"Failed to process analysis for ticket {ticket.ticket_id}")
    except Exception as e:
        logger.error(f"Error generating analysis: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    generate_analysis()