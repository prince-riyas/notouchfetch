import sys
import os
import json
from datetime import datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pandas as pd
from sqlalchemy.orm import Session
from models.models import NewTicket, EmailInteraction
from core.database import SessionLocal, init_db

def export_tickets():
    # Initialize the database schema
    init_db()
    
    db = SessionLocal()
    try:
        # Query all tickets
        tickets = db.query(NewTicket).all()
        print(f"Retrieved {len(tickets)} tickets from database")
        
        # Prepare data for Excel
        data = []
        for ticket in tickets:
            # Fetch related EmailInteraction (reply only)
            reply = db.query(EmailInteraction).filter(
                EmailInteraction.ticket_id == ticket.ticket_id,
                EmailInteraction.email_type == "reply"
            ).first()
            
            # Convert additional_info to string
            ticket_additional_info = json.dumps(ticket.additional_info) if ticket.additional_info else ""
            reply_additional_info = json.dumps(reply.additional_info) if reply and reply.additional_info else ""
            
            # Build row
            row = {
                "ticket_id": ticket.ticket_id,
                "email": ticket.email,
                "description": ticket.description,
                "status": ticket.status,
                "source": ticket.source,
                "created_at": ticket.created_at,
                "additional_info": ticket_additional_info,
                "reply_body": reply.body if reply else "",
                "reply_additional_info": reply_additional_info,
                "reply_sent_at": reply.sent_at if reply else None
            }
            data.append(row)
            print(f"Processed ticket {ticket.ticket_id}")
        
        # Create DataFrame
        df = pd.DataFrame(data)
        print(f"DataFrame shape: {df.shape}")
        print(f"DataFrame content:\n{df.head()}")
        
        # Ensure output directory exists
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_dir = os.path.join(script_dir, "data")
        os.makedirs(output_dir, exist_ok=True)
        
        # Save to Excel
        output_path = os.path.join(output_dir, "tickets.xlsx")
        df.to_excel(output_path, index=False)
        print(f"Exported tickets to {output_path}")
    except Exception as e:
        print(f"Error exporting tickets: {str(e)}")
    finally:
        db.close()

if __name__ == "__main__":
    export_tickets()